# 아래의 [보기]의 주어진 코드를 활용하여, 다음 요구사항에 따라 출력결과와 일치하는 코드를 완성하시오.

# 보기
li = ['월','화','수','목','금','토','일']

weekday = li[0:5]
weekend = li[5:]

print(weekday)
print(weekend)